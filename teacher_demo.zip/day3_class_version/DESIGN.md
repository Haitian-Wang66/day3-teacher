# Design for Lab 1

1. I am going to make at least 5 API calls to the OpenAI API
2. Maybe it makes sense to write some reusable code so I don't keep repeating myself
3. If an element is not satisfied, stop and explain to the user what the element requires and why it isn't satisfied