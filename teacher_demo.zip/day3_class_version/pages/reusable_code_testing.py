import streamlit as st
from reusable_code.ask_ai import ask_ai

user_input = st.text_area(label="test_question")

response = ask_ai(user_input)
st.write(response)