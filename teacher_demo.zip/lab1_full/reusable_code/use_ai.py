import openai as OpenAI
from dotenv import load_dotenv
import tiktoken

load_dotenv()

def ask_ai(prompt):
    client = OpenAI.OpenAI()
    response = client.responses.create(
        model="gpt-4o",
        input=prompt
    )
    return response.output_text

def ask_ai_yes_no(prompt):
    client = OpenAI.OpenAI()

    enc = tiktoken.encoding_for_model("gpt-4o")
    yes_id = enc.encode("Yes")[0]
    no_id = enc.encode("No")[0]

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt + " Answer only Yes or No."}],
        max_tokens=1,
        logit_bias={yes_id: 100, no_id: 100}
    )
    return response.choices[0].message.content