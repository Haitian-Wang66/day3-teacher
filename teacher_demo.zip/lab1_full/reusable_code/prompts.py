
system_prompt = "You are an expert contracts lawyer."

offer_and_acceptance_requirements = """
A contract forms when one party makes an offer that is accepted by the other party.
The offer must be definite and contain essential terms (e.g., price, quantity, quality).
Offers can be made to specific individuals, groups, or the general public.
Acceptance must be unequivocal and communicated to the offeror.
Counter-offers terminate the original offer and create a new one.
Offers can be withdrawn before acceptance.
"""

intention_to_create_legal_relations_requirements = """
Parties must intend to enter a legally binding agreement.
Commercial arrangements generally presume this intention.
Domestic or social arrangements may require clear expression of intent.
Courts consider objective factors rather than subjective intent.
Written agreements can help establish intention in ambiguous situations.
"""

consideration_requirements = """
Something of value exchanged between parties.
Need not be adequate, but must be real and have some value.
Can be a benefit to one party or a detriment to the other.
Past consideration is generally not valid.
Exceptions: deeds do not require consideration but must meet specific formal requirements.
"""

legal_capacity_requirements = """
Certain groups have limited capacity to contract: minors, people with mental impairments, bankrupt individuals, and prisoners.
Minors can only enter binding contracts for necessities.
Contracts with incapacitated individuals may be voidable.
Companies have legal capacity to contract through authorized representatives.
"""

consent_requirements = """
Must be genuine and free from factors that undermine it.
Factors affecting consent include mistake, misrepresentation, duress, and undue influence.
Remedies for vitiated consent may include rescission, damages, or contract termination.
Unfair terms in standard form consumer contracts may be void.
"""

illegal_and_void_contracts_requirements = """
Contracts for illegal activities or against public policy are generally void.
Examples include contracts to commit crimes, sexually immoral contracts, or contracts in unreasonable restraint of trade.
Partially illegal contracts may be enforceable if the illegal part can be severed.
Statutory prohibitions may render certain contracts or terms unenforceable.
A valid contract requires all these elements to be present. The absence or flaw in any element may render the contract void, voidable, or unenforceable, depending on the specific circumstances.
"""