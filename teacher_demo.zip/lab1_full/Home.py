import streamlit as st
import json
from reusable_code.use_ai import ask_ai_yes_no
from reusable_code.prompts import offer_and_acceptance_requirements, intention_to_create_legal_relations_requirements, consideration_requirements, legal_capacity_requirements, illegal_and_void_contracts_requirements, consent_requirements

if "contract_elements" not in st.session_state:
    st.session_state.contract_elements = {
        "offer_and_acceptance": offer_and_acceptance_requirements,
        "intention_to_create_legal_relations": intention_to_create_legal_relations_requirements,
        "consideration": consideration_requirements,
        "legal_capacity": legal_capacity_requirements,
        "consent": consent_requirements,
        "illegal_and_void_contracts": illegal_and_void_contracts_requirements
    }

if "hypothetical" not in st.session_state:
    st.session_state.hypothetical = None

if "evaluation" not in st.session_state:
    st.session_state.evaluation = {
        "offer_and_acceptance": "no",
        "intention_to_create_legal_relations": "no",
        "consideration": "no",
        "legal_capacity": "no",
        "consent": "no",
        "illegal_and_void_contracts": "no"
    }

def examine_element(hypothetical, element, element_requirement):

    instruction_prompt = f"""
    You have the following legal hypothetical:
    <hypothetical>
    {hypothetical}
    </hypothetical>
    Your task is to determine whether the following element of contract formation has been satisfied:
    <element>
    {element}
    </element>
    Satisfication of the element requires the following:
    <element_requirements>
    {element_requirement}
    <element_requirements>
    """

    response = ask_ai_yes_no(instruction_prompt)

    return response

st.markdown("## Legal AI - Lab 1")

st.markdown("What is your contractual hypothetical?")

st.session_state.hypothetical = st.text_area(
    label="hypothetical",
    value=None,
    label_visibility="collapsed"
)

if st.session_state.hypothetical is not None:

    if st.button("Evaluate"):

        st.markdown("### Advice")

        with st.spinner("Working..."):

            contract_formed = True

            for element, element_requirement in st.session_state.contract_elements.items():

                st.session_state.evaluation[element] = examine_element(
                    st.session_state.hypothetical,
                    element, 
                    element_requirement
                )

                if st.session_state.evaluation[element] == "no":
                    st.write(f"It was determined for {element} that the element is NOT satisfied. No further progress.")
                    contract_formed = False
                    break
                
                else:
                    st.write(f"It was determined for {element} that the element IS satisfied. Continuing...")
            
            if contract_formed:
                st.write("There has been valid contract formation.")



